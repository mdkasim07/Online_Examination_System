import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Button } from '../components/Button';
import { BookOpen, Clock, CheckCircle } from 'lucide-react';

interface Exam {
  id: string;
  title: string;
  duration: number;
  status: 'upcoming' | 'completed';
  score?: number;
}

export function StudentDashboard() {
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      const { data: examData, error } = await supabase
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setExams(examData || []);
    } catch (error) {
      console.error('Error fetching exams:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Student Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <BookOpen className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold ml-2">Upcoming Exams</h2>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <ul className="space-y-4">
                {exams
                  .filter((exam) => exam.status === 'upcoming')
                  .map((exam) => (
                    <li
                      key={exam.id}
                      className="border-b pb-4 last:border-b-0 last:pb-0"
                    >
                      <h3 className="font-medium">{exam.title}</h3>
                      <div className="flex items-center text-sm text-gray-600 mt-1">
                        <Clock className="w-4 h-4 mr-1" />
                        <span>{exam.duration} minutes</span>
                      </div>
                      <Button className="mt-2" variant="outline">
                        Start Exam
                      </Button>
                    </li>
                  ))}
              </ul>
            )}
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <h2 className="text-xl font-semibold ml-2">Completed Exams</h2>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <ul className="space-y-4">
                {exams
                  .filter((exam) => exam.status === 'completed')
                  .map((exam) => (
                    <li
                      key={exam.id}
                      className="border-b pb-4 last:border-b-0 last:pb-0"
                    >
                      <h3 className="font-medium">{exam.title}</h3>
                      <div className="flex items-center justify-between text-sm text-gray-600 mt-1">
                        <span>Score: {exam.score}%</span>
                      </div>
                      <Button className="mt-2" variant="secondary">
                        View Results
                      </Button>
                    </li>
                  ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}