import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Users, FileText, Plus, Trash2 } from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface Exam {
  id: string;
  title: string;
  duration: number;
}

export function AdminDashboard() {
  const [users, setUsers] = useState<User[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [newExam, setNewExam] = useState({ title: '', duration: 60 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [usersResponse, examsResponse] = await Promise.all([
        supabase.from('users').select('*'),
        supabase.from('exams').select('*'),
      ]);

      if (usersResponse.error) throw usersResponse.error;
      if (examsResponse.error) throw examsResponse.error;

      setUsers(usersResponse.data || []);
      setExams(examsResponse.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateExam = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { error } = await supabase.from('exams').insert([newExam]);
      if (error) throw error;
      fetchData();
      setNewExam({ title: '', duration: 60 });
    } catch (error) {
      console.error('Error creating exam:', error);
    }
  };

  const handleDeleteExam = async (examId: string) => {
    try {
      const { error } = await supabase.from('exams').delete().eq('id', examId);
      if (error) throw error;
      fetchData();
    } catch (error) {
      console.error('Error deleting exam:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-6">
              <Users className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold ml-2">Users</h2>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Name</th>
                      <th className="text-left py-2">Email</th>
                      <th className="text-left py-2">Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id} className="border-b">
                        <td className="py-2">{user.name}</td>
                        <td className="py-2">{user.email}</td>
                        <td className="py-2">{user.role}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-6">
              <FileText className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold ml-2">Exams</h2>
            </div>

            <form onSubmit={handleCreateExam} className="mb-6">
              <div className="flex gap-4">
                <Input
                  placeholder="Exam Title"
                  value={newExam.title}
                  onChange={(e) =>
                    setNewExam({ ...newExam, title: e.target.value })
                  }
                  required
                />
                <Input
                  type="number"
                  placeholder="Duration (minutes)"
                  value={newExam.duration}
                  onChange={(e) =>
                    setNewExam({
                      ...newExam,
                      duration: parseInt(e.target.value) || 60,
                    })
                  }
                  required
                />
                <Button type="submit">
                  <Plus className="w-4 h-4" />
                  Add
                </Button>
              </div>
            </form>

            {loading ? (
              <p>Loading...</p>
            ) : (
              <div className="space-y-4">
                {exams.map((exam) => (
                  <div
                    key={exam.id}
                    className="flex items-center justify-between border-b pb-4"
                  >
                    <div>
                      <h3 className="font-medium">{exam.title}</h3>
                      <p className="text-sm text-gray-600">
                        Duration: {exam.duration} minutes
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline">Edit</Button>
                      <Button
                        variant="secondary"
                        onClick={() => handleDeleteExam(exam.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}