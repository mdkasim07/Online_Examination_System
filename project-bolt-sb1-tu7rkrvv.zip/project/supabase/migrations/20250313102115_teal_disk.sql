/*
  # Initial Schema Setup for Online Examination System

  1. New Tables
    - users
      - id (uuid, primary key)
      - name (text)
      - role (text)
      - created_at (timestamp)
    
    - exams
      - id (uuid, primary key)
      - title (text)
      - duration (integer, minutes)
      - created_at (timestamp)
      - created_by (uuid, references users)
    
    - exam_submissions
      - id (uuid, primary key)
      - exam_id (uuid, references exams)
      - user_id (uuid, references users)
      - score (integer)
      - submitted_at (timestamp)
      - status (text)

  2. Security
    - Enable RLS on all tables
    - Add policies for:
      - Users can read their own data
      - Admins can read all data
      - Students can read exams
      - Students can create exam submissions
      - Admins can create and manage exams
*/

-- Create users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  role text NOT NULL DEFAULT 'student',
  created_at timestamptz DEFAULT now()
);

-- Create exams table
CREATE TABLE exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  duration integer NOT NULL DEFAULT 60,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES users(id)
);

-- Create exam submissions table
CREATE TABLE exam_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid REFERENCES exams(id),
  user_id uuid REFERENCES users(id),
  score integer,
  submitted_at timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'pending'
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_submissions ENABLE ROW LEVEL SECURITY;

-- Users policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can read all users"
  ON users
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid() AND role = 'admin'
  ));

-- Exams policies
CREATE POLICY "Students can read exams"
  ON exams
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage exams"
  ON exams
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid() AND role = 'admin'
  ));

-- Exam submissions policies
CREATE POLICY "Students can create and read own submissions"
  ON exam_submissions
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can read all submissions"
  ON exam_submissions
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid() AND role = 'admin'
  ));